"""
Crop data management and agricultural knowledge base
"""

class CropDatabase:
    def __init__(self):
        self.crop_characteristics = self._load_crop_characteristics()
        self.seasonal_calendar = self._load_seasonal_calendar()
        self.regional_adaptations = self._load_regional_adaptations()
    
    def _load_crop_characteristics(self):
        """Load detailed crop characteristics"""
        return {
            'Rice': {
                'scientific_name': 'Oryza sativa',
                'family': 'Poaceae',
                'optimal_conditions': {
                    'temperature': (20, 35),
                    'rainfall': (1000, 2000),
                    'soil_ph': (5.5, 7.0),
                    'humidity': (70, 90)
                },
                'growth_stages': {
                    'germination': '7-10 days',
                    'vegetative': '40-50 days',
                    'reproductive': '30-35 days',
                    'maturation': '20-25 days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'High',
                    'phosphorus': 'Medium',
                    'potassium': 'Medium'
                },
                'common_varieties': ['Basmati', 'Jasmine', 'Arborio', 'Brown Rice'],
                'pest_diseases': ['Blast', 'Bacterial blight', 'Brown planthopper'],
                'market_price_range': (20, 40)  # per kg in local currency
            },
            'Wheat': {
                'scientific_name': 'Triticum aestivum',
                'family': 'Poaceae',
                'optimal_conditions': {
                    'temperature': (15, 25),
                    'rainfall': (300, 700),
                    'soil_ph': (6.0, 7.5),
                    'humidity': (50, 70)
                },
                'growth_stages': {
                    'germination': '5-7 days',
                    'tillering': '30-40 days',
                    'stem_elongation': '30-35 days',
                    'grain_filling': '30-40 days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'High',
                    'phosphorus': 'High',
                    'potassium': 'Medium'
                },
                'common_varieties': ['Hard Red Winter', 'Soft White', 'Durum'],
                'pest_diseases': ['Rust', 'Aphids', 'Fusarium head blight'],
                'market_price_range': (15, 30)
            },
            'Corn': {
                'scientific_name': 'Zea mays',
                'family': 'Poaceae',
                'optimal_conditions': {
                    'temperature': (18, 30),
                    'rainfall': (500, 1000),
                    'soil_ph': (5.8, 7.0),
                    'humidity': (60, 80)
                },
                'growth_stages': {
                    'emergence': '5-10 days',
                    'vegetative': '45-55 days',
                    'tasseling': '10-15 days',
                    'grain_filling': '45-55 days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'Very High',
                    'phosphorus': 'Medium',
                    'potassium': 'High'
                },
                'common_varieties': ['Dent corn', 'Sweet corn', 'Popcorn'],
                'pest_diseases': ['Corn borer', 'Armyworm', 'Gray leaf spot'],
                'market_price_range': (12, 25)
            },
            'Cotton': {
                'scientific_name': 'Gossypium hirsutum',
                'family': 'Malvaceae',
                'optimal_conditions': {
                    'temperature': (21, 35),
                    'rainfall': (500, 1200),
                    'soil_ph': (5.8, 8.0),
                    'humidity': (55, 75)
                },
                'growth_stages': {
                    'emergence': '5-10 days',
                    'squaring': '35-45 days',
                    'flowering': '45-65 days',
                    'boll_development': '45-60 days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'High',
                    'phosphorus': 'Medium',
                    'potassium': 'High'
                },
                'common_varieties': ['Upland cotton', 'Pima cotton'],
                'pest_diseases': ['Bollworm', 'Whitefly', 'Fusarium wilt'],
                'market_price_range': (50, 80)
            },
            'Sugarcane': {
                'scientific_name': 'Saccharum officinarum',
                'family': 'Poaceae',
                'optimal_conditions': {
                    'temperature': (20, 35),
                    'rainfall': (1000, 2000),
                    'soil_ph': (6.0, 7.5),
                    'humidity': (70, 85)
                },
                'growth_stages': {
                    'germination': '15-30 days',
                    'tillering': '60-90 days',
                    'grand_growth': '180-240 days',
                    'maturation': '90-120 days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'Very High',
                    'phosphorus': 'Medium',
                    'potassium': 'High'
                },
                'common_varieties': ['Co-86032', 'Co-0238', 'CoM-0265'],
                'pest_diseases': ['Red rot', 'Smut', 'Pyrilla'],
                'market_price_range': (3, 5)  # per kg
            },
            'Pulses': {
                'scientific_name': 'Leguminosae family',
                'family': 'Fabaceae',
                'optimal_conditions': {
                    'temperature': (15, 30),
                    'rainfall': (300, 800),
                    'soil_ph': (6.0, 7.5),
                    'humidity': (50, 70)
                },
                'growth_stages': {
                    'germination': '7-14 days',
                    'vegetative': '30-40 days',
                    'flowering': '15-25 days',
                    'pod_filling': '20-30 days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'Low',  # Self-fixing
                    'phosphorus': 'High',
                    'potassium': 'Medium'
                },
                'common_varieties': ['Chickpea', 'Lentil', 'Black gram', 'Green gram'],
                'pest_diseases': ['Pod borer', 'Aphids', 'Wilt'],
                'market_price_range': (40, 80)
            },
            'Vegetables': {
                'scientific_name': 'Various families',
                'family': 'Mixed',
                'optimal_conditions': {
                    'temperature': (15, 30),
                    'rainfall': (400, 1000),
                    'soil_ph': (6.0, 7.0),
                    'humidity': (60, 80)
                },
                'growth_stages': {
                    'germination': '3-14 days',
                    'vegetative': '20-40 days',
                    'flowering': '10-20 days',
                    'harvesting': '30-60 days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'High',
                    'phosphorus': 'High',
                    'potassium': 'High'
                },
                'common_varieties': ['Tomato', 'Potato', 'Onion', 'Cabbage', 'Carrot'],
                'pest_diseases': ['Aphids', 'Whitefly', 'Fungal diseases'],
                'market_price_range': (10, 50)
            },
            'Fruits': {
                'scientific_name': 'Various families',
                'family': 'Mixed',
                'optimal_conditions': {
                    'temperature': (20, 30),
                    'rainfall': (600, 1500),
                    'soil_ph': (5.5, 7.0),
                    'humidity': (65, 85)
                },
                'growth_stages': {
                    'planting': '0 days',
                    'establishment': '30-90 days',
                    'growth': '180-365 days',
                    'production': '365+ days'
                },
                'nutritional_requirements': {
                    'nitrogen': 'Medium',
                    'phosphorus': 'Medium',
                    'potassium': 'High'
                },
                'common_varieties': ['Mango', 'Apple', 'Banana', 'Orange', 'Grapes'],
                'pest_diseases': ['Fruit fly', 'Scale insects', 'Anthracnose'],
                'market_price_range': (20, 100)
            }
        }
    
    def _load_seasonal_calendar(self):
        """Load seasonal planting calendar"""
        return {
            'spring': {
                'recommended_crops': ['Vegetables', 'Corn', 'Pulses'],
                'temperature_range': (15, 25),
                'activities': ['Land preparation', 'Sowing', 'Irrigation setup']
            },
            'summer': {
                'recommended_crops': ['Rice', 'Cotton', 'Sugarcane', 'Fruits'],
                'temperature_range': (25, 35),
                'activities': ['Intensive irrigation', 'Pest monitoring', 'Fertilizer application']
            },
            'monsoon': {
                'recommended_crops': ['Rice', 'Corn', 'Sugarcane'],
                'temperature_range': (20, 30),
                'activities': ['Drainage management', 'Disease control', 'Weed management']
            },
            'winter': {
                'recommended_crops': ['Wheat', 'Pulses', 'Vegetables'],
                'temperature_range': (10, 20),
                'activities': ['Harvesting', 'Storage preparation', 'Soil preparation']
            }
        }
    
    def _load_regional_adaptations(self):
        """Load regional crop adaptations"""
        return {
            'north': {
                'climate': 'Temperate to sub-tropical',
                'soil_types': ['Alluvial', 'Sandy loam'],
                'major_crops': ['Wheat', 'Rice', 'Sugarcane'],
                'challenges': ['Water scarcity', 'Extreme temperatures'],
                'recommendations': ['Drought-resistant varieties', 'Efficient irrigation']
            },
            'south': {
                'climate': 'Tropical to sub-tropical',
                'soil_types': ['Red soil', 'Black soil'],
                'major_crops': ['Rice', 'Cotton', 'Sugarcane', 'Fruits'],
                'challenges': ['Pest pressure', 'High humidity'],
                'recommendations': ['Integrated pest management', 'Resistant varieties']
            },
            'east': {
                'climate': 'Humid subtropical',
                'soil_types': ['Alluvial', 'Laterite'],
                'major_crops': ['Rice', 'Corn', 'Vegetables'],
                'challenges': ['Flooding', 'Cyclones'],
                'recommendations': ['Flood-resistant varieties', 'Early warning systems']
            },
            'west': {
                'climate': 'Arid to semi-arid',
                'soil_types': ['Sandy', 'Desert soil'],
                'major_crops': ['Cotton', 'Pulses', 'Fruits'],
                'challenges': ['Water scarcity', 'Salinity'],
                'recommendations': ['Drip irrigation', 'Salt-tolerant crops']
            },
            'central': {
                'climate': 'Continental',
                'soil_types': ['Black soil', 'Red soil'],
                'major_crops': ['Wheat', 'Cotton', 'Pulses'],
                'challenges': ['Irregular rainfall', 'Soil degradation'],
                'recommendations': ['Soil conservation', 'Crop rotation']
            }
        }
    
    def get_crop_info(self, crop_name):
        """Get detailed information about a specific crop"""
        return self.crop_characteristics.get(crop_name, {})
    
    def get_seasonal_recommendations(self, season):
        """Get crops recommended for a specific season"""
        return self.seasonal_calendar.get(season, {})
    
    def get_regional_info(self, region):
        """Get regional agricultural information"""
        return self.regional_adaptations.get(region, {})
    
    def get_compatible_crops(self, conditions):
        """
        Find crops compatible with given conditions
        
        Args:
            conditions (dict): Environmental conditions
        
        Returns:
            list: Compatible crops with suitability scores
        """
        compatible_crops = []
        
        for crop, info in self.crop_characteristics.items():
            optimal = info.get('optimal_conditions', {})
            score = 0
            total_factors = 0
            
            # Check temperature compatibility
            if 'temperature' in conditions and 'temperature' in optimal:
                temp = conditions['temperature']
                temp_range = optimal['temperature']
                if temp_range[0] <= temp <= temp_range[1]:
                    score += 25
                elif abs(temp - sum(temp_range)/2) <= 5:
                    score += 15
                total_factors += 25
            
            # Check pH compatibility
            if 'soil_ph' in conditions and 'soil_ph' in optimal:
                ph = conditions['soil_ph']
                ph_range = optimal['soil_ph']
                if ph_range[0] <= ph <= ph_range[1]:
                    score += 25
                elif abs(ph - sum(ph_range)/2) <= 0.5:
                    score += 15
                total_factors += 25
            
            # Check rainfall compatibility
            if 'rainfall' in conditions and 'rainfall' in optimal:
                rainfall = conditions['rainfall']
                rain_range = optimal['rainfall']
                if rain_range[0] <= rainfall <= rain_range[1]:
                    score += 25
                elif abs(rainfall - sum(rain_range)/2) <= 200:
                    score += 15
                total_factors += 25
            
            # Check humidity compatibility
            if 'humidity' in conditions and 'humidity' in optimal:
                humidity = conditions['humidity']
                hum_range = optimal['humidity']
                if hum_range[0] <= humidity <= hum_range[1]:
                    score += 25
                elif abs(humidity - sum(hum_range)/2) <= 10:
                    score += 15
                total_factors += 25
            
            if total_factors > 0:
                suitability = score / total_factors
                compatible_crops.append({
                    'crop': crop,
                    'suitability': suitability,
                    'info': info
                })
        
        # Sort by suitability score
        compatible_crops.sort(key=lambda x: x['suitability'], reverse=True)
        
        return compatible_crops
