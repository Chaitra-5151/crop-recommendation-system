"""
Data persistence utilities for storing and retrieving user recommendations
"""

import json
import os
from datetime import datetime
import pandas as pd

class DataPersistence:
    def __init__(self):
        self.data_dir = 'user_data'
        self.recommendations_file = os.path.join(self.data_dir, 'recommendations.json')
        self._ensure_data_directory()
    
    def _ensure_data_directory(self):
        """Ensure data directory exists"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
    
    def save_recommendation(self, user_id, input_data, recommendation):
        """
        Save a recommendation to the user's history
        
        Args:
            user_id (str): User identifier
            input_data (dict): Input parameters used for recommendation
            recommendation (dict): Recommendation result
        """
        try:
            # Load existing data
            data = self._load_recommendations_data()
            
            # Create new recommendation entry
            new_entry = {
                'user_id': user_id,
                'timestamp': datetime.now().isoformat(),
                'input_data': input_data,
                'recommended_crop': recommendation.get('crop', 'Unknown'),
                'confidence': recommendation.get('confidence', 0.0),
                'soil_ph': input_data.get('soil_ph', 0),
                'temperature': input_data.get('temperature', 0),
                'rainfall': input_data.get('rainfall', 0),
                'humidity': input_data.get('humidity', 0),
                'season': input_data.get('season', 'Unknown'),
                'region': input_data.get('region', 'Unknown'),
                'yield_info': recommendation.get('yield', 'N/A'),
                'growing_period': recommendation.get('growing_period', 'N/A'),
                'water_requirement': recommendation.get('water_requirement', 'N/A'),
                'tips': recommendation.get('tips', [])
            }
            
            # Add to data
            data.append(new_entry)
            
            # Save back to file
            self._save_recommendations_data(data)
            
        except Exception as e:
            print(f"Error saving recommendation: {e}")
    
    def get_user_history(self, user_id):
        """
        Get recommendation history for a specific user
        
        Args:
            user_id (str): User identifier
            
        Returns:
            list: List of user's recommendation history
        """
        try:
            data = self._load_recommendations_data()
            user_data = [entry for entry in data if entry.get('user_id') == user_id]
            
            # Sort by timestamp (newest first)
            user_data.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
            
            return user_data
        except Exception as e:
            print(f"Error getting user history: {e}")
            return []
    
    def get_all_recommendations(self):
        """Get all recommendations from all users"""
        return self._load_recommendations_data()
    
    def get_user_statistics(self, user_id):
        """
        Get statistics for a specific user
        
        Args:
            user_id (str): User identifier
            
        Returns:
            dict: User statistics
        """
        try:
            history = self.get_user_history(user_id)
            
            if not history:
                return {
                    'total_recommendations': 0,
                    'unique_crops': 0,
                    'average_confidence': 0.0,
                    'most_recommended_crop': 'N/A',
                    'recent_recommendations': 0
                }
            
            # Convert to DataFrame for easier analysis
            df = pd.DataFrame(history)
            
            # Calculate statistics
            total_recommendations = len(history)
            unique_crops = df['recommended_crop'].nunique()
            average_confidence = df['confidence'].mean()
            most_recommended_crop = df['recommended_crop'].mode().iloc[0] if len(df) > 0 else 'N/A'
            
            # Recent recommendations (last 30 days)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            thirty_days_ago = pd.Timestamp.now() - pd.Timedelta(days=30)
            recent_recommendations = len(df[df['timestamp'] >= thirty_days_ago])
            
            return {
                'total_recommendations': total_recommendations,
                'unique_crops': unique_crops,
                'average_confidence': average_confidence,
                'most_recommended_crop': most_recommended_crop,
                'recent_recommendations': recent_recommendations
            }
            
        except Exception as e:
            print(f"Error calculating user statistics: {e}")
            return {
                'total_recommendations': 0,
                'unique_crops': 0,
                'average_confidence': 0.0,
                'most_recommended_crop': 'N/A',
                'recent_recommendations': 0
            }
    
    def export_user_data(self, user_id, format='csv'):
        """
        Export user data to CSV or JSON format
        
        Args:
            user_id (str): User identifier
            format (str): Export format ('csv' or 'json')
            
        Returns:
            str: File path of exported data
        """
        try:
            history = self.get_user_history(user_id)
            
            if not history:
                return None
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            if format.lower() == 'csv':
                # Convert to DataFrame and export to CSV
                df = pd.DataFrame(history)
                filename = f'user_{user_id}_recommendations_{timestamp}.csv'
                filepath = os.path.join(self.data_dir, filename)
                df.to_csv(filepath, index=False)
                
            elif format.lower() == 'json':
                # Export to JSON
                filename = f'user_{user_id}_recommendations_{timestamp}.json'
                filepath = os.path.join(self.data_dir, filename)
                with open(filepath, 'w') as f:
                    json.dump(history, f, indent=2)
            
            else:
                raise ValueError("Format must be 'csv' or 'json'")
            
            return filepath
            
        except Exception as e:
            print(f"Error exporting user data: {e}")
            return None
    
    def _load_recommendations_data(self):
        """Load recommendations data from file"""
        try:
            if os.path.exists(self.recommendations_file):
                with open(self.recommendations_file, 'r') as f:
                    return json.load(f)
            else:
                return []
        except Exception as e:
            print(f"Error loading recommendations data: {e}")
            return []
    
    def _save_recommendations_data(self, data):
        """Save recommendations data to file"""
        try:
            with open(self.recommendations_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving recommendations data: {e}")
    
    def clear_user_data(self, user_id):
        """
        Clear all data for a specific user
        
        Args:
            user_id (str): User identifier
        """
        try:
            data = self._load_recommendations_data()
            data = [entry for entry in data if entry.get('user_id') != user_id]
            self._save_recommendations_data(data)
        except Exception as e:
            print(f"Error clearing user data: {e}")
    
    def get_crop_performance_data(self, user_id):
        """
        Get crop performance data for analysis
        
        Args:
            user_id (str): User identifier
            
        Returns:
            dict: Performance data by crop
        """
        try:
            history = self.get_user_history(user_id)
            
            if not history:
                return {}
            
            # Group by crop and calculate metrics
            crop_data = {}
            
            for entry in history:
                crop = entry.get('recommended_crop', 'Unknown')
                
                if crop not in crop_data:
                    crop_data[crop] = {
                        'count': 0,
                        'total_confidence': 0,
                        'seasons': [],
                        'regions': []
                    }
                
                crop_data[crop]['count'] += 1
                crop_data[crop]['total_confidence'] += entry.get('confidence', 0)
                
                season = entry.get('season')
                region = entry.get('region')
                
                if season and season not in crop_data[crop]['seasons']:
                    crop_data[crop]['seasons'].append(season)
                
                if region and region not in crop_data[crop]['regions']:
                    crop_data[crop]['regions'].append(region)
            
            # Calculate average confidence for each crop
            for crop in crop_data:
                if crop_data[crop]['count'] > 0:
                    crop_data[crop]['avg_confidence'] = (
                        crop_data[crop]['total_confidence'] / crop_data[crop]['count']
                    )
                else:
                    crop_data[crop]['avg_confidence'] = 0
            
            return crop_data
            
        except Exception as e:
            print(f"Error getting crop performance data: {e}")
            return {}
