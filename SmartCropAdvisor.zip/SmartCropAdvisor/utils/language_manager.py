"""
Multi-language support for the crop recommendation system
"""

class LanguageManager:
    def __init__(self):
        self.current_language = 'English'
        self.translations = self._load_translations()
    
    def _load_translations(self):
        """Load all translations"""
        return {
            'English': {
                # Navigation
                'navigation_title': 'Navigation',
                'home': 'Home',
                'recommendations': 'Get Recommendations',
                'dashboard': 'Dashboard',
                'about': 'About',
                
                # Home page
                'welcome_title': '🌾 Smart Crop Recommender for Farmers',
                'welcome_description': '''
                Welcome to your AI-powered farming assistant! Our system helps small-scale farmers 
                make informed decisions about crop selection based on your local conditions.
                
                **Key Features:**
                - 🤖 AI-powered crop recommendations
                - 🌍 Multi-language support
                - 📊 Performance tracking dashboard
                - 💡 Expert farming tips and guidance
                - 📱 Mobile-friendly interface
                ''',
                'total_recommendations': 'Total Recommendations',
                'supported_crops': 'Supported Crops',
                'accuracy_rate': 'Accuracy Rate',
                'quick_recommendation': '🚀 Quick Recommendation',
                'get_recommendation': 'Get Recommendation',
                
                # Input fields
                'soil_ph': 'Soil pH Level',
                'temperature': 'Average Temperature (°C)',
                'rainfall': 'Annual Rainfall (mm)',
                'humidity': 'Humidity (%)',
                'season': 'Current Season',
                'region': 'Your Region',
                'soil_type': 'Soil Type',
                'nitrogen_content': 'Nitrogen Content (%)',
                'phosphorus_content': 'Phosphorus Content (%)',
                'potassium_content': 'Potassium Content (%)',
                'avg_temperature': 'Average Temperature (°C)',
                'annual_rainfall': 'Annual Rainfall (mm)',
                'planting_season': 'Planting Season',
                'farm_size': 'Farm Size (hectares)',
                
                # Seasons
                'spring': 'Spring',
                'summer': 'Summer',
                'monsoon': 'Monsoon',
                'winter': 'Winter',
                
                # Regions
                'north': 'Northern',
                'south': 'Southern',
                'east': 'Eastern',
                'west': 'Western',
                'central': 'Central',
                
                # Soil types
                'clay': 'Clay',
                'sandy': 'Sandy',
                'loamy': 'Loamy',
                'silt': 'Silt',
                'peat': 'Peat',
                
                # Results
                'recommended_crop': 'Recommended Crop',
                'confidence': 'Confidence',
                'recommendation_error': 'Unable to generate recommendation. Please check your inputs.',
                
                # Recommendations page
                'detailed_recommendations': '🎯 Detailed Crop Recommendations',
                'recommendations_description': '''
                Get comprehensive crop recommendations based on detailed soil, climate, and location data.
                The more accurate information you provide, the better our recommendations will be.
                ''',
                'soil_information': '🌱 Soil Information',
                'climate_information': '🌤️ Climate Information',
                'location_information': '📍 Location Information',
                'get_detailed_recommendation': 'Get Detailed Recommendations',
                'recommendations_generated': 'Recommendations generated successfully!',
                'crop_details': 'Crop Details',
                'expected_yield': 'Expected Yield',
                'growing_period': 'Growing Period',
                'water_requirement': 'Water Requirement',
                'farming_tips': 'Farming Tips',
                
                # Dashboard
                'farmer_dashboard': '📊 Farmer Dashboard',
                'no_recommendations_yet': 'No recommendations yet. Start by getting your first crop recommendation!',
                'unique_crops_recommended': 'Unique Crops',
                'avg_confidence': 'Avg. Confidence',
                'recent_recommendations': 'This Month',
                'crop_distribution': 'Crop Distribution',
                'recommended_crops_distribution': 'Distribution of Recommended Crops',
                'recommendations_over_time': 'Recommendations Timeline',
                'monthly_recommendations': 'Monthly Recommendations',
                'number_of_recommendations': 'Number of Recommendations',
                'recent_recommendations_history': 'Recent Recommendations History',
                'date': 'Date',
                'crop': 'Crop',
                
                # About page
                'about_title': 'About Smart Crop Recommender',
                'about_description': '''
                The Smart Crop Recommender is an AI-powered agricultural decision support system 
                designed specifically for small-scale farmers. Our mission is to democratize access 
                to expert agricultural knowledge and help farmers increase productivity while promoting 
                sustainable farming practices.
                
                ### Our Mission
                To empower small-scale farmers with data-driven insights for better crop selection, 
                leading to improved yields, income, and food security.
                
                ### Technology
                Our system uses machine learning algorithms trained on agricultural data to provide 
                personalized crop recommendations based on your local environmental conditions.
                ''',
                'features': 'Key Features',
                'feature_ai_powered': 'AI-powered recommendations based on soil, climate, and regional data',
                'feature_multilingual': 'Multi-language support for better accessibility',
                'feature_dashboard': 'Personal dashboard to track recommendations and performance',
                'feature_tips': 'Expert farming tips and best practices',
                'feature_history': 'Recommendation history and analysis',
                'how_it_works': 'How It Works',
                'how_it_works_description': '''
                1. **Input Your Data**: Provide information about your soil, climate, and location
                2. **AI Analysis**: Our machine learning model analyzes your conditions
                3. **Get Recommendations**: Receive personalized crop suggestions with confidence scores
                4. **Follow Tips**: Implement our expert farming advice
                5. **Track Progress**: Monitor your results in the dashboard
                ''',
                'supported_crops': 'Supported Crops'
            },
            
            'Hindi': {
                # Navigation
                'navigation_title': 'नेवीगेशन',
                'home': 'होम',
                'recommendations': 'सुझाव प्राप्त करें',
                'dashboard': 'डैशबोर्ड',
                'about': 'के बारे में',
                
                # Home page
                'welcome_title': '🌾 किसानों के लिए स्मार्ट फसल सुझावकर्ता',
                'welcome_description': '''
                आपके AI-संचालित कृषि सहायक में आपका स्वागत है! हमारा सिस्टम छोटे किसानों को 
                स्थानीय परिस्थितियों के आधार पर फसल चयन के बारे में सूचित निर्णय लेने में मदद करता है।
                
                **मुख्य विशेषताएं:**
                - 🤖 AI-संचालित फसल सुझाव
                - 🌍 बहुभाषी समर्थन
                - 📊 प्रदर्शन ट्रैकिंग डैशबोर्ड
                - 💡 विशेषज्ञ कृषि सुझाव और मार्गदर्शन
                - 📱 मोबाइल-फ्रेंडली इंटरफेस
                ''',
                'total_recommendations': 'कुल सुझाव',
                'supported_crops': 'समर्थित फसलें',
                'accuracy_rate': 'सटीकता दर',
                'quick_recommendation': '🚀 त्वरित सुझाव',
                'get_recommendation': 'सुझाव प्राप्त करें',
                
                # Input fields
                'soil_ph': 'मिट्टी का pH स्तर',
                'temperature': 'औसत तापमान (°C)',
                'rainfall': 'वार्षिक वर्षा (mm)',
                'humidity': 'आर्द्रता (%)',
                'season': 'वर्तमान मौसम',
                'region': 'आपका क्षेत्र',
                'soil_type': 'मिट्टी का प्रकार',
                'nitrogen_content': 'नाइट्रोजन सामग्री (%)',
                'phosphorus_content': 'फास्फोरस सामग्री (%)',
                'potassium_content': 'पोटेशियम सामग्री (%)',
                'avg_temperature': 'औसत तापमान (°C)',
                'annual_rainfall': 'वार्षिक वर्षा (mm)',
                'planting_season': 'बुआई का मौसम',
                'farm_size': 'खेत का आकार (हेक्टेयर)',
                
                # Seasons
                'spring': 'वसंत',
                'summer': 'गर्मी',
                'monsoon': 'मानसून',
                'winter': 'सर्दी',
                
                # Regions
                'north': 'उत्तरी',
                'south': 'दक्षिणी',
                'east': 'पूर्वी',
                'west': 'पश्चिमी',
                'central': 'मध्य',
                
                # Soil types
                'clay': 'मिट्टी',
                'sandy': 'रेतीली',
                'loamy': 'दोमट',
                'silt': 'गाद',
                'peat': 'पीट',
                
                # Results
                'recommended_crop': 'सुझाई गई फसल',
                'confidence': 'विश्वास',
                'recommendation_error': 'सुझाव उत्पन्न करने में असमर्थ। कृपया अपने इनपुट की जांच करें।',
                
                # Recommendations page
                'detailed_recommendations': '🎯 विस्तृत फसल सुझाव',
                'recommendations_description': '''
                विस्तृत मिट्टी, जलवायु और स्थान डेटा के आधार पर व्यापक फसल सुझाव प्राप्त करें।
                आप जितनी सटीक जानकारी प्रदान करेंगे, हमारे सुझाव उतने बेहतर होंगे।
                ''',
                'soil_information': '🌱 मिट्टी की जानकारी',
                'climate_information': '🌤️ जलवायु की जानकारी',
                'location_information': '📍 स्थान की जानकारी',
                'get_detailed_recommendation': 'विस्तृत सुझाव प्राप्त करें',
                'recommendations_generated': 'सुझाव सफलतापूर्वक उत्पन्न हुए!',
                'crop_details': 'फसल विवरण',
                'expected_yield': 'अपेक्षित उत्पादन',
                'growing_period': 'उगने की अवधि',
                'water_requirement': 'पानी की आवश्यकता',
                'farming_tips': 'कृषि सुझाव',
                
                # Dashboard
                'farmer_dashboard': '📊 किसान डैशबोर्ड',
                'no_recommendations_yet': 'अभी तक कोई सुझाव नहीं। अपना पहला फसल सुझाव प्राप्त करके शुरुआत करें!',
                'unique_crops_recommended': 'अनोखी फसलें',
                'avg_confidence': 'औसत विश्वास',
                'recent_recommendations': 'इस महीने',
                'crop_distribution': 'फसल वितरण',
                'recommended_crops_distribution': 'सुझाई गई फसलों का वितरण',
                'recommendations_over_time': 'सुझाव समयरेखा',
                'monthly_recommendations': 'मासिक सुझाव',
                'number_of_recommendations': 'सुझावों की संख्या',
                'recent_recommendations_history': 'हाल के सुझावों का इतिहास',
                'date': 'दिनांक',
                'crop': 'फसल',
                
                # About page
                'about_title': 'स्मार्ट फसल सुझावकर्ता के बारे में',
                'about_description': '''
                स्मार्ट फसल सुझावकर्ता एक AI-संचालित कृषि निर्णय सहायता प्रणाली है जो विशेष रूप से 
                छोटे किसानों के लिए डिज़ाइन की गई है। हमारा मिशन विशेषज्ञ कृषि ज्ञान तक पहुंच को 
                लोकतांत्रिक बनाना और किसानों को टिकाऊ कृषि प्रथाओं को बढ़ावा देते हुए उत्पादकता 
                बढ़ाने में मदद करना है।
                
                ### हमारा मिशन
                बेहतर फसल चयन के लिए डेटा-संचालित अंतर्दृष्टि के साथ छोटे किसानों को सशक्त बनाना,
                जिससे बेहतर उत्पादन, आय और खाद्य सुरक्षा हो।
                
                ### तकनीक
                हमारा सिस्टम आपकी स्थानीय पर्यावरणीय परिस्थितियों के आधार पर व्यक्तिगत फसल सुझाव 
                प्रदान करने के लिए कृषि डेटा पर प्रशिक्षित मशीन लर्निंग एल्गोरिदम का उपयोग करता है।
                ''',
                'features': 'मुख्य विशेषताएं',
                'feature_ai_powered': 'मिट्टी, जलवायु और क्षेत्रीय डेटा के आधार पर AI-संचालित सुझाव',
                'feature_multilingual': 'बेहतर पहुंच के लिए बहुभाषी समर्थन',
                'feature_dashboard': 'सुझावों और प्रदर्शन को ट्रैक करने के लिए व्यक्तिगत डैशबोर्ड',
                'feature_tips': 'विशेषज्ञ कृषि सुझाव और सर्वोत्तम प्रथाएं',
                'feature_history': 'सुझाव इतिहास और विश्लेषण',
                'how_it_works': 'यह कैसे काम करता है',
                'how_it_works_description': '''
                1. **अपना डेटा इनपुट करें**: अपनी मिट्टी, जलवायु और स्थान के बारे में जानकारी प्रदान करें
                2. **AI विश्लेषण**: हमारा मशीन लर्निंग मॉडल आपकी परिस्थितियों का विश्लेषण करता है
                3. **सुझाव प्राप्त करें**: विश्वास स्कोर के साथ व्यक्तिगत फसल सुझाव प्राप्त करें
                4. **सुझावों का पालन करें**: हमारी विशेषज्ञ कृषि सलाह को लागू करें
                5. **प्रगति ट्रैक करें**: डैशबोर्ड में अपने परिणामों की निगरानी करें
                ''',
                'supported_crops': 'समर्थित फसलें'
            },
            
            'Spanish': {
                # Navigation
                'navigation_title': 'Navegación',
                'home': 'Inicio',
                'recommendations': 'Obtener Recomendaciones',
                'dashboard': 'Panel de Control',
                'about': 'Acerca de',
                
                # Home page
                'welcome_title': '🌾 Recomendador Inteligente de Cultivos para Agricultores',
                'welcome_description': '''
                ¡Bienvenido a su asistente agrícola impulsado por IA! Nuestro sistema ayuda a los 
                pequeños agricultores a tomar decisiones informadas sobre la selección de cultivos 
                basándose en sus condiciones locales.
                
                **Características Principales:**
                - 🤖 Recomendaciones de cultivos impulsadas por IA
                - 🌍 Soporte multiidioma
                - 📊 Panel de seguimiento de rendimiento
                - 💡 Consejos expertos de agricultura y orientación
                - 📱 Interfaz amigable para móviles
                ''',
                'total_recommendations': 'Recomendaciones Totales',
                'supported_crops': 'Cultivos Soportados',
                'accuracy_rate': 'Tasa de Precisión',
                'quick_recommendation': '🚀 Recomendación Rápida',
                'get_recommendation': 'Obtener Recomendación',
                
                # Input fields
                'soil_ph': 'Nivel de pH del Suelo',
                'temperature': 'Temperatura Promedio (°C)',
                'rainfall': 'Precipitación Anual (mm)',
                'humidity': 'Humedad (%)',
                'season': 'Temporada Actual',
                'region': 'Su Región',
                'soil_type': 'Tipo de Suelo',
                'nitrogen_content': 'Contenido de Nitrógeno (%)',
                'phosphorus_content': 'Contenido de Fósforo (%)',
                'potassium_content': 'Contenido de Potasio (%)',
                'avg_temperature': 'Temperatura Promedio (°C)',
                'annual_rainfall': 'Precipitación Anual (mm)',
                'planting_season': 'Temporada de Siembra',
                'farm_size': 'Tamaño de la Granja (hectáreas)',
                
                # Seasons
                'spring': 'Primavera',
                'summer': 'Verano',
                'monsoon': 'Monzón',
                'winter': 'Invierno',
                
                # Regions
                'north': 'Norte',
                'south': 'Sur',
                'east': 'Este',
                'west': 'Oeste',
                'central': 'Central',
                
                # Soil types
                'clay': 'Arcilla',
                'sandy': 'Arenoso',
                'loamy': 'Franco',
                'silt': 'Limo',
                'peat': 'Turba',
                
                # Results
                'recommended_crop': 'Cultivo Recomendado',
                'confidence': 'Confianza',
                'recommendation_error': 'No se puede generar recomendación. Por favor, verifique sus entradas.',
                
                # Recommendations page
                'detailed_recommendations': '🎯 Recomendaciones Detalladas de Cultivos',
                'recommendations_description': '''
                Obtenga recomendaciones integrales de cultivos basadas en datos detallados de suelo, 
                clima y ubicación. Cuanta más información precisa proporcione, mejores serán nuestras 
                recomendaciones.
                ''',
                'soil_information': '🌱 Información del Suelo',
                'climate_information': '🌤️ Información del Clima',
                'location_information': '📍 Información de Ubicación',
                'get_detailed_recommendation': 'Obtener Recomendaciones Detalladas',
                'recommendations_generated': '¡Recomendaciones generadas exitosamente!',
                'crop_details': 'Detalles del Cultivo',
                'expected_yield': 'Rendimiento Esperado',
                'growing_period': 'Período de Crecimiento',
                'water_requirement': 'Requerimiento de Agua',
                'farming_tips': 'Consejos Agrícolas',
                
                # Dashboard
                'farmer_dashboard': '📊 Panel del Agricultor',
                'no_recommendations_yet': '¡Aún no hay recomendaciones. Comience obteniendo su primera recomendación de cultivo!',
                'unique_crops_recommended': 'Cultivos Únicos',
                'avg_confidence': 'Confianza Prom.',
                'recent_recommendations': 'Este Mes',
                'crop_distribution': 'Distribución de Cultivos',
                'recommended_crops_distribution': 'Distribución de Cultivos Recomendados',
                'recommendations_over_time': 'Cronología de Recomendaciones',
                'monthly_recommendations': 'Recomendaciones Mensuales',
                'number_of_recommendations': 'Número de Recomendaciones',
                'recent_recommendations_history': 'Historial de Recomendaciones Recientes',
                'date': 'Fecha',
                'crop': 'Cultivo',
                
                # About page
                'about_title': 'Acerca del Recomendador Inteligente de Cultivos',
                'about_description': '''
                El Recomendador Inteligente de Cultivos es un sistema de apoyo a la decisión agrícola 
                impulsado por IA diseñado específicamente para pequeños agricultores. Nuestra misión 
                es democratizar el acceso al conocimiento agrícola experto y ayudar a los agricultores 
                a aumentar la productividad mientras se promueven prácticas agrícolas sostenibles.
                
                ### Nuestra Misión
                Empoderar a los pequeños agricultores con conocimientos basados en datos para una mejor 
                selección de cultivos, llevando a mejores rendimientos, ingresos y seguridad alimentaria.
                
                ### Tecnología
                Nuestro sistema utiliza algoritmos de aprendizaje automático entrenados en datos agrícolas 
                para proporcionar recomendaciones personalizadas de cultivos basadas en sus condiciones 
                ambientales locales.
                ''',
                'features': 'Características Principales',
                'feature_ai_powered': 'Recomendaciones impulsadas por IA basadas en datos de suelo, clima y región',
                'feature_multilingual': 'Soporte multiidioma para mejor accesibilidad',
                'feature_dashboard': 'Panel personal para rastrear recomendaciones y rendimiento',
                'feature_tips': 'Consejos expertos de agricultura y mejores prácticas',
                'feature_history': 'Historial y análisis de recomendaciones',
                'how_it_works': 'Cómo Funciona',
                'how_it_works_description': '''
                1. **Ingrese Sus Datos**: Proporcione información sobre su suelo, clima y ubicación
                2. **Análisis de IA**: Nuestro modelo de aprendizaje automático analiza sus condiciones
                3. **Obtenga Recomendaciones**: Reciba sugerencias personalizadas de cultivos con puntuaciones de confianza
                4. **Siga los Consejos**: Implemente nuestro consejo agrícola experto
                5. **Rastree el Progreso**: Monitoree sus resultados en el panel de control
                ''',
                'supported_crops': 'Cultivos Soportados'
            }
        }
    
    def set_language(self, language):
        """Set the current language"""
        if language in self.translations:
            self.current_language = language
    
    def get_text(self, key):
        """Get translated text for a given key"""
        return self.translations.get(self.current_language, {}).get(key, key)
    
    def get_available_languages(self):
        """Get list of available languages"""
        return list(self.translations.keys())
