import streamlit as st
import pandas as pd
from utils.language_manager import LanguageManager
from utils.data_persistence import DataPersistence
from models.crop_recommender import CropRecommender
import plotly.express as px
import plotly.graph_objects as go

# Initialize session state
if 'language' not in st.session_state:
    st.session_state.language = 'English'

if 'user_id' not in st.session_state:
    st.session_state.user_id = 'farmer_001'  # In real app, this would be from authentication

# Initialize components
lang_manager = LanguageManager()
data_persistence = DataPersistence()
crop_recommender = CropRecommender()

def main():
    st.set_page_config(
        page_title="Smart Crop Recommender",
        page_icon="🌾",
        layout="wide"
    )
    
    # Language selector in sidebar
    st.sidebar.title("🌾 Smart Crop Recommender")
    
    # Language selection
    languages = ['English', 'Hindi', 'Spanish']
    selected_language = st.sidebar.selectbox(
        "Select Language / भाषा चुनें / Seleccionar idioma:",
        languages,
        index=languages.index(st.session_state.language)
    )
    
    if selected_language != st.session_state.language:
        st.session_state.language = selected_language
        st.rerun()
    
    lang_manager.set_language(st.session_state.language)
    
    # Navigation
    page = st.sidebar.radio(
        lang_manager.get_text("navigation_title"),
        [
            lang_manager.get_text("home"),
            lang_manager.get_text("recommendations"),
            lang_manager.get_text("dashboard"),
            lang_manager.get_text("about")
        ]
    )
    
    if page == lang_manager.get_text("home"):
        show_home_page()
    elif page == lang_manager.get_text("recommendations"):
        show_recommendations_page()
    elif page == lang_manager.get_text("dashboard"):
        show_dashboard_page()
    elif page == lang_manager.get_text("about"):
        show_about_page()

def show_home_page():
    st.title(lang_manager.get_text("welcome_title"))
    st.markdown(lang_manager.get_text("welcome_description"))
    
    # Quick stats
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            lang_manager.get_text("total_recommendations"),
            len(data_persistence.get_user_history(st.session_state.user_id))
        )
    
    with col2:
        st.metric(
            lang_manager.get_text("supported_crops"),
            len(crop_recommender.get_supported_crops())
        )
    
    with col3:
        st.metric(
            lang_manager.get_text("accuracy_rate"),
            "92%"
        )
    
    # Quick recommendation form
    st.subheader(lang_manager.get_text("quick_recommendation"))
    
    with st.form("quick_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            soil_ph = st.slider(
                lang_manager.get_text("soil_ph"),
                min_value=4.0,
                max_value=9.0,
                value=6.5,
                step=0.1
            )
            temperature = st.slider(
                lang_manager.get_text("temperature"),
                min_value=10,
                max_value=45,
                value=25,
                step=1
            )
        
        with col2:
            rainfall = st.slider(
                lang_manager.get_text("rainfall"),
                min_value=50,
                max_value=2000,
                value=800,
                step=50
            )
            humidity = st.slider(
                lang_manager.get_text("humidity"),
                min_value=30,
                max_value=90,
                value=60,
                step=5
            )
        
        season = st.selectbox(
            lang_manager.get_text("season"),
            [lang_manager.get_text(s) for s in ["spring", "summer", "monsoon", "winter"]]
        )
        
        region = st.selectbox(
            lang_manager.get_text("region"),
            [lang_manager.get_text(r) for r in ["north", "south", "east", "west", "central"]]
        )
        
        submitted = st.form_submit_button(lang_manager.get_text("get_recommendation"))
        
        if submitted:
            # Map back to English for processing
            season_map = {
                lang_manager.get_text("spring"): "spring",
                lang_manager.get_text("summer"): "summer", 
                lang_manager.get_text("monsoon"): "monsoon",
                lang_manager.get_text("winter"): "winter"
            }
            
            region_map = {
                lang_manager.get_text("north"): "north",
                lang_manager.get_text("south"): "south",
                lang_manager.get_text("east"): "east", 
                lang_manager.get_text("west"): "west",
                lang_manager.get_text("central"): "central"
            }
            
            input_data = {
                'soil_ph': soil_ph,
                'temperature': temperature,
                'rainfall': rainfall,
                'humidity': humidity,
                'season': season_map[season],
                'region': region_map[region]
            }
            
            recommendation = crop_recommender.recommend_crop(input_data)
            
            if recommendation:
                st.success(f"🌾 {lang_manager.get_text('recommended_crop')}: **{recommendation['crop']}**")
                st.info(f"📊 {lang_manager.get_text('confidence')}: {recommendation['confidence']:.1%}")
                
                # Save recommendation
                data_persistence.save_recommendation(
                    st.session_state.user_id,
                    input_data,
                    recommendation
                )
                
                st.balloons()
            else:
                st.error(lang_manager.get_text("recommendation_error"))

def show_recommendations_page():
    st.title(lang_manager.get_text("detailed_recommendations"))
    st.markdown(lang_manager.get_text("recommendations_description"))
    
    with st.form("detailed_form"):
        # Soil Information
        st.subheader(lang_manager.get_text("soil_information"))
        col1, col2 = st.columns(2)
        
        with col1:
            soil_type = st.selectbox(
                lang_manager.get_text("soil_type"),
                [lang_manager.get_text(t) for t in ["clay", "sandy", "loamy", "silt", "peat"]]
            )
            soil_ph = st.number_input(
                lang_manager.get_text("soil_ph"),
                min_value=4.0,
                max_value=9.0,
                value=6.5,
                step=0.1
            )
        
        with col2:
            nitrogen = st.slider(
                lang_manager.get_text("nitrogen_content"),
                min_value=0,
                max_value=100,
                value=50,
                step=5
            )
            phosphorus = st.slider(
                lang_manager.get_text("phosphorus_content"),
                min_value=0,
                max_value=100,
                value=50,
                step=5
            )
        
        potassium = st.slider(
            lang_manager.get_text("potassium_content"),
            min_value=0,
            max_value=100,
            value=50,
            step=5
        )
        
        # Climate Information
        st.subheader(lang_manager.get_text("climate_information"))
        col1, col2 = st.columns(2)
        
        with col1:
            temperature = st.number_input(
                lang_manager.get_text("avg_temperature"),
                min_value=10,
                max_value=45,
                value=25,
                step=1
            )
            rainfall = st.number_input(
                lang_manager.get_text("annual_rainfall"),
                min_value=50,
                max_value=2000,
                value=800,
                step=50
            )
        
        with col2:
            humidity = st.slider(
                lang_manager.get_text("humidity"),
                min_value=30,
                max_value=90,
                value=60,
                step=5
            )
            season = st.selectbox(
                lang_manager.get_text("planting_season"),
                [lang_manager.get_text(s) for s in ["spring", "summer", "monsoon", "winter"]]
            )
        
        # Location Information
        st.subheader(lang_manager.get_text("location_information"))
        col1, col2 = st.columns(2)
        
        with col1:
            region = st.selectbox(
                lang_manager.get_text("region"),
                [lang_manager.get_text(r) for r in ["north", "south", "east", "west", "central"]]
            )
        
        with col2:
            farm_size = st.number_input(
                lang_manager.get_text("farm_size"),
                min_value=0.1,
                max_value=100.0,
                value=2.0,
                step=0.1
            )
        
        submitted = st.form_submit_button(lang_manager.get_text("get_detailed_recommendation"))
        
        if submitted:
            # Process the detailed recommendation
            season_map = {
                lang_manager.get_text("spring"): "spring",
                lang_manager.get_text("summer"): "summer", 
                lang_manager.get_text("monsoon"): "monsoon",
                lang_manager.get_text("winter"): "winter"
            }
            
            region_map = {
                lang_manager.get_text("north"): "north",
                lang_manager.get_text("south"): "south",
                lang_manager.get_text("east"): "east", 
                lang_manager.get_text("west"): "west",
                lang_manager.get_text("central"): "central"
            }
            
            soil_type_map = {
                lang_manager.get_text("clay"): "clay",
                lang_manager.get_text("sandy"): "sandy",
                lang_manager.get_text("loamy"): "loamy",
                lang_manager.get_text("silt"): "silt",
                lang_manager.get_text("peat"): "peat"
            }
            
            detailed_input = {
                'soil_type': soil_type_map[soil_type],
                'soil_ph': soil_ph,
                'nitrogen': nitrogen,
                'phosphorus': phosphorus,
                'potassium': potassium,
                'temperature': temperature,
                'rainfall': rainfall,
                'humidity': humidity,
                'season': season_map[season],
                'region': region_map[region],
                'farm_size': farm_size
            }
            
            recommendations = crop_recommender.get_multiple_recommendations(detailed_input)
            
            if recommendations:
                st.success(lang_manager.get_text("recommendations_generated"))
                
                # Display top recommendations
                for i, rec in enumerate(recommendations[:3], 1):
                    with st.expander(f"{i}. {rec['crop']} - {rec['confidence']:.1%} {lang_manager.get_text('confidence')}"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write(f"**{lang_manager.get_text('crop_details')}:**")
                            st.write(f"• {lang_manager.get_text('expected_yield')}: {rec.get('yield', 'N/A')}")
                            st.write(f"• {lang_manager.get_text('growing_period')}: {rec.get('growing_period', 'N/A')}")
                            st.write(f"• {lang_manager.get_text('water_requirement')}: {rec.get('water_requirement', 'N/A')}")
                        
                        with col2:
                            st.write(f"**{lang_manager.get_text('farming_tips')}:**")
                            for tip in rec.get('tips', []):
                                st.write(f"• {tip}")
                
                # Save detailed recommendation
                data_persistence.save_recommendation(
                    st.session_state.user_id,
                    detailed_input,
                    recommendations[0] if recommendations else None
                )
            else:
                st.error(lang_manager.get_text("recommendation_error"))

def show_dashboard_page():
    st.title(lang_manager.get_text("farmer_dashboard"))
    
    # Get user history
    history = data_persistence.get_user_history(st.session_state.user_id)
    
    if not history:
        st.info(lang_manager.get_text("no_recommendations_yet"))
        return
    
    # Convert to DataFrame for analysis
    df = pd.DataFrame(history)
    df['date'] = pd.to_datetime(df['timestamp'])
    
    # Dashboard metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            lang_manager.get_text("total_recommendations"),
            len(history)
        )
    
    with col2:
        unique_crops = df['recommended_crop'].nunique()
        st.metric(
            lang_manager.get_text("unique_crops_recommended"),
            unique_crops
        )
    
    with col3:
        avg_confidence = df['confidence'].mean()
        st.metric(
            lang_manager.get_text("avg_confidence"),
            f"{avg_confidence:.1%}"
        )
    
    with col4:
        recent_recommendations = len(df[df['date'] >= pd.Timestamp.now() - pd.Timedelta(days=30)])
        st.metric(
            lang_manager.get_text("recent_recommendations"),
            recent_recommendations
        )
    
    # Visualizations
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader(lang_manager.get_text("crop_distribution"))
        crop_counts = df['recommended_crop'].value_counts()
        fig = px.pie(
            values=crop_counts.values,
            names=crop_counts.index,
            title=lang_manager.get_text("recommended_crops_distribution")
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader(lang_manager.get_text("recommendations_over_time"))
        df_monthly = df.groupby(df['date'].dt.to_period('M')).size().reset_index()
        df_monthly['date'] = df_monthly['date'].astype(str)
        
        fig = px.line(
            df_monthly,
            x='date',
            y=0,
            title=lang_manager.get_text("monthly_recommendations")
        )
        fig.update_layout(yaxis_title=lang_manager.get_text("number_of_recommendations"))
        st.plotly_chart(fig, use_container_width=True)
    
    # Recent recommendations table
    st.subheader(lang_manager.get_text("recent_recommendations_history"))
    
    recent_df = df.tail(10)[['date', 'recommended_crop', 'confidence', 'soil_ph', 'temperature', 'rainfall']]
    recent_df['date'] = recent_df['date'].dt.strftime('%Y-%m-%d')
    recent_df['confidence'] = recent_df['confidence'].apply(lambda x: f"{x:.1%}")
    
    # Rename columns for display
    display_df = recent_df.rename(columns={
        'date': lang_manager.get_text('date'),
        'recommended_crop': lang_manager.get_text('crop'),
        'confidence': lang_manager.get_text('confidence'),
        'soil_ph': lang_manager.get_text('soil_ph'),
        'temperature': lang_manager.get_text('temperature'),
        'rainfall': lang_manager.get_text('rainfall')
    })
    
    st.dataframe(display_df, use_container_width=True)

def show_about_page():
    st.title(lang_manager.get_text("about_title"))
    
    st.markdown(lang_manager.get_text("about_description"))
    
    st.subheader(lang_manager.get_text("features"))
    features = [
        lang_manager.get_text("feature_ai_powered"),
        lang_manager.get_text("feature_multilingual"),
        lang_manager.get_text("feature_dashboard"),
        lang_manager.get_text("feature_tips"),
        lang_manager.get_text("feature_history")
    ]
    
    for feature in features:
        st.write(f"• {feature}")
    
    st.subheader(lang_manager.get_text("how_it_works"))
    st.markdown(lang_manager.get_text("how_it_works_description"))
    
    st.subheader(lang_manager.get_text("supported_crops"))
    crops = crop_recommender.get_supported_crops()
    
    # Display crops in columns
    num_cols = 3
    cols = st.columns(num_cols)
    
    for i, crop in enumerate(crops):
        col_idx = i % num_cols
        cols[col_idx].write(f"🌾 {crop}")

if __name__ == "__main__":
    main()
