import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import joblib
import os

class CropRecommender:
    def __init__(self):
        self.model = None
        self.label_encoders = {}
        self.feature_columns = ['soil_ph', 'temperature', 'rainfall', 'humidity', 'season_encoded', 'region_encoded']
        self.crops_info = self._load_crops_info()
        self._train_model()
    
    def _load_crops_info(self):
        """Load crop information and characteristics"""
        return {
            'Rice': {
                'yield': '3-4 tons/hectare',
                'growing_period': '120-150 days',
                'water_requirement': 'High (1200-1800mm)',
                'tips': [
                    'Requires flooded fields for optimal growth',
                    'Plant during monsoon season',
                    'Maintain water level 2-5cm above soil',
                    'Apply nitrogen fertilizer in split doses'
                ]
            },
            'Wheat': {
                'yield': '2-3 tons/hectare',
                'growing_period': '120-140 days',
                'water_requirement': 'Medium (450-650mm)',
                'tips': [
                    'Best grown in winter season',
                    'Requires well-drained soil',
                    'Apply phosphorus fertilizer before sowing',
                    'Harvest when grain moisture is 20-25%'
                ]
            },
            'Corn': {
                'yield': '4-6 tons/hectare',
                'growing_period': '90-120 days',
                'water_requirement': 'Medium (500-800mm)',
                'tips': [
                    'Plant after last frost date',
                    'Requires adequate spacing between plants',
                    'Side-dress with nitrogen when plants are knee-high',
                    'Monitor for corn borers and apply organic pesticides'
                ]
            },
            'Cotton': {
                'yield': '1.5-2.5 tons/hectare',
                'growing_period': '180-200 days',
                'water_requirement': 'Medium (700-1000mm)',
                'tips': [
                    'Requires warm weather and long growing season',
                    'Deep plowing recommended before sowing',
                    'Regular weeding is essential',
                    'Monitor for bollworm and whitefly'
                ]
            },
            'Sugarcane': {
                'yield': '70-80 tons/hectare',
                'growing_period': '12-18 months',
                'water_requirement': 'High (1500-2000mm)',
                'tips': [
                    'Plant healthy, disease-free seedlings',
                    'Requires regular irrigation',
                    'Apply organic manure before planting',
                    'Harvest when sugar content is maximum'
                ]
            },
            'Pulses': {
                'yield': '1-2 tons/hectare',
                'growing_period': '90-120 days',
                'water_requirement': 'Low-Medium (400-600mm)',
                'tips': [
                    'Fix nitrogen naturally, reducing fertilizer need',
                    'Rotate with cereal crops',
                    'Avoid waterlogging',
                    'Harvest when pods are dry and rattle'
                ]
            },
            'Vegetables': {
                'yield': '15-25 tons/hectare',
                'growing_period': '60-90 days',
                'water_requirement': 'Medium (400-700mm)',
                'tips': [
                    'Requires rich, well-drained soil',
                    'Regular watering and mulching',
                    'Companion planting for pest control',
                    'Harvest at optimal maturity for best quality'
                ]
            },
            'Fruits': {
                'yield': '10-20 tons/hectare',
                'growing_period': '6-12 months',
                'water_requirement': 'Medium-High (800-1200mm)',
                'tips': [
                    'Choose varieties suitable for local climate',
                    'Proper pruning and training',
                    'Integrated pest management',
                    'Post-harvest handling is crucial'
                ]
            }
        }
    
    def _generate_training_data(self):
        """Generate synthetic training data based on agricultural knowledge"""
        np.random.seed(42)
        n_samples = 1000
        
        data = []
        crops = list(self.crops_info.keys())
        seasons = ['spring', 'summer', 'monsoon', 'winter']
        regions = ['north', 'south', 'east', 'west', 'central']
        
        # Define crop preferences
        crop_preferences = {
            'Rice': {
                'ph_range': (5.5, 7.0),
                'temp_range': (20, 35),
                'rainfall_range': (1000, 2000),
                'humidity_range': (70, 90),
                'preferred_seasons': ['monsoon', 'summer'],
                'preferred_regions': ['east', 'south', 'west']
            },
            'Wheat': {
                'ph_range': (6.0, 7.5),
                'temp_range': (15, 25),
                'rainfall_range': (300, 700),
                'humidity_range': (50, 70),
                'preferred_seasons': ['winter'],
                'preferred_regions': ['north', 'central', 'west']
            },
            'Corn': {
                'ph_range': (5.8, 7.0),
                'temp_range': (18, 30),
                'rainfall_range': (500, 1000),
                'humidity_range': (60, 80),
                'preferred_seasons': ['summer', 'monsoon'],
                'preferred_regions': ['central', 'north', 'east']
            },
            'Cotton': {
                'ph_range': (5.8, 8.0),
                'temp_range': (21, 35),
                'rainfall_range': (500, 1200),
                'humidity_range': (55, 75),
                'preferred_seasons': ['summer'],
                'preferred_regions': ['central', 'south', 'west']
            },
            'Sugarcane': {
                'ph_range': (6.0, 7.5),
                'temp_range': (20, 35),
                'rainfall_range': (1000, 2000),
                'humidity_range': (70, 85),
                'preferred_seasons': ['monsoon', 'summer'],
                'preferred_regions': ['south', 'west', 'central']
            },
            'Pulses': {
                'ph_range': (6.0, 7.5),
                'temp_range': (15, 30),
                'rainfall_range': (300, 800),
                'humidity_range': (50, 70),
                'preferred_seasons': ['winter', 'spring'],
                'preferred_regions': ['central', 'north', 'south']
            },
            'Vegetables': {
                'ph_range': (6.0, 7.0),
                'temp_range': (15, 30),
                'rainfall_range': (400, 1000),
                'humidity_range': (60, 80),
                'preferred_seasons': ['spring', 'winter'],
                'preferred_regions': ['north', 'central', 'east']
            },
            'Fruits': {
                'ph_range': (5.5, 7.0),
                'temp_range': (20, 30),
                'rainfall_range': (600, 1500),
                'humidity_range': (65, 85),
                'preferred_seasons': ['spring', 'summer'],
                'preferred_regions': ['south', 'west', 'central']
            }
        }
        
        for _ in range(n_samples):
            # Randomly select a crop
            crop = np.random.choice(crops)
            prefs = crop_preferences[crop]
            
            # Generate features based on crop preferences with some noise
            soil_ph = np.random.normal(
                (prefs['ph_range'][0] + prefs['ph_range'][1]) / 2,
                (prefs['ph_range'][1] - prefs['ph_range'][0]) / 4
            )
            soil_ph = np.clip(soil_ph, 4.0, 9.0)
            
            temperature = np.random.normal(
                (prefs['temp_range'][0] + prefs['temp_range'][1]) / 2,
                (prefs['temp_range'][1] - prefs['temp_range'][0]) / 4
            )
            temperature = np.clip(temperature, 10, 45)
            
            rainfall = np.random.normal(
                (prefs['rainfall_range'][0] + prefs['rainfall_range'][1]) / 2,
                (prefs['rainfall_range'][1] - prefs['rainfall_range'][0]) / 4
            )
            rainfall = np.clip(rainfall, 50, 2000)
            
            humidity = np.random.normal(
                (prefs['humidity_range'][0] + prefs['humidity_range'][1]) / 2,
                (prefs['humidity_range'][1] - prefs['humidity_range'][0]) / 4
            )
            humidity = np.clip(humidity, 30, 90)
            
            # Bias towards preferred seasons and regions
            season = np.random.choice(
                seasons,
                p=[0.7/len(prefs['preferred_seasons']) if s in prefs['preferred_seasons'] 
                   else 0.3/(len(seasons)-len(prefs['preferred_seasons'])) for s in seasons]
            )
            
            region = np.random.choice(
                regions,
                p=[0.7/len(prefs['preferred_regions']) if r in prefs['preferred_regions'] 
                   else 0.3/(len(regions)-len(prefs['preferred_regions'])) for r in regions]
            )
            
            data.append({
                'soil_ph': round(soil_ph, 1),
                'temperature': round(temperature),
                'rainfall': round(rainfall),
                'humidity': round(humidity),
                'season': season,
                'region': region,
                'crop': crop
            })
        
        return pd.DataFrame(data)
    
    def _train_model(self):
        """Train the machine learning model"""
        # Generate training data
        df = self._generate_training_data()
        
        # Encode categorical variables
        self.label_encoders['season'] = LabelEncoder()
        self.label_encoders['region'] = LabelEncoder()
        
        df['season_encoded'] = self.label_encoders['season'].fit_transform(df['season'])
        df['region_encoded'] = self.label_encoders['region'].fit_transform(df['region'])
        
        # Prepare features and target
        X = df[self.feature_columns]
        y = df['crop']
        
        # Train Random Forest model
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            class_weight='balanced'
        )
        self.model.fit(X, y)
    
    def recommend_crop(self, input_data):
        """
        Recommend a single crop based on input parameters
        
        Args:
            input_data (dict): Dictionary containing soil_ph, temperature, rainfall, 
                             humidity, season, region
        
        Returns:
            dict: Recommendation with crop name and confidence
        """
        try:
            # Prepare input features
            features = self._prepare_features(input_data)
            
            # Get prediction and probability
            prediction = self.model.predict([features])[0]
            probabilities = self.model.predict_proba([features])[0]
            confidence = max(probabilities)
            
            # Get crop info
            crop_info = self.crops_info.get(prediction, {})
            
            return {
                'crop': prediction,
                'confidence': confidence,
                'yield': crop_info.get('yield', 'N/A'),
                'growing_period': crop_info.get('growing_period', 'N/A'),
                'water_requirement': crop_info.get('water_requirement', 'N/A'),
                'tips': crop_info.get('tips', [])
            }
        except Exception as e:
            print(f"Error in recommendation: {e}")
            return None
    
    def get_multiple_recommendations(self, input_data, top_n=3):
        """
        Get multiple crop recommendations ranked by confidence
        
        Args:
            input_data (dict): Input parameters
            top_n (int): Number of top recommendations to return
        
        Returns:
            list: List of recommendations sorted by confidence
        """
        try:
            # Prepare input features
            features = self._prepare_features(input_data)
            
            # Get probabilities for all classes
            probabilities = self.model.predict_proba([features])[0]
            classes = self.model.classes_
            
            # Create list of (crop, confidence) pairs
            crop_probs = list(zip(classes, probabilities))
            
            # Sort by confidence (descending)
            crop_probs.sort(key=lambda x: x[1], reverse=True)
            
            # Return top N recommendations with details
            recommendations = []
            for crop, confidence in crop_probs[:top_n]:
                crop_info = self.crops_info.get(crop, {})
                recommendations.append({
                    'crop': crop,
                    'confidence': confidence,
                    'yield': crop_info.get('yield', 'N/A'),
                    'growing_period': crop_info.get('growing_period', 'N/A'),
                    'water_requirement': crop_info.get('water_requirement', 'N/A'),
                    'tips': crop_info.get('tips', [])
                })
            
            return recommendations
        except Exception as e:
            print(f"Error in multiple recommendations: {e}")
            return []
    
    def _prepare_features(self, input_data):
        """Prepare features for model prediction"""
        # Encode categorical variables
        season_encoded = self.label_encoders['season'].transform([input_data['season']])[0]
        region_encoded = self.label_encoders['region'].transform([input_data['region']])[0]
        
        # Create feature array
        features = [
            input_data['soil_ph'],
            input_data['temperature'],
            input_data['rainfall'],
            input_data['humidity'],
            season_encoded,
            region_encoded
        ]
        
        return features
    
    def get_supported_crops(self):
        """Return list of supported crops"""
        return list(self.crops_info.keys())
    
    def get_feature_importance(self):
        """Get feature importance from the trained model"""
        if self.model:
            importance = self.model.feature_importances_
            features = ['Soil pH', 'Temperature', 'Rainfall', 'Humidity', 'Season', 'Region']
            return dict(zip(features, importance))
        return {}
