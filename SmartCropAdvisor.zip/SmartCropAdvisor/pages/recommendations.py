"""
Recommendations page implementation (currently integrated in main app.py)
This file can be used for future modularization
"""

import streamlit as st
from models.crop_recommender import CropRecommender
from utils.data_persistence import DataPersistence
from utils.language_manager import LanguageManager

def render_recommendations_page(user_id, lang_manager, data_persistence, crop_recommender):
    """
    Render the detailed recommendations page
    
    Args:
        user_id (str): User identifier
        lang_manager (LanguageManager): Language manager instance
        data_persistence (DataPersistence): Data persistence instance
        crop_recommender (CropRecommender): Crop recommender instance
    """
    st.title(lang_manager.get_text("detailed_recommendations"))
    st.markdown(lang_manager.get_text("recommendations_description"))
    
    # Input validation helper
    def validate_input(value, min_val, max_val, field_name):
        if value < min_val or value > max_val:
            st.warning(f"{field_name} should be between {min_val} and {max_val}")
            return False
        return True
    
    with st.form("detailed_form"):
        # Soil Information Section
        st.subheader(lang_manager.get_text("soil_information"))
        
        col1, col2 = st.columns(2)
        
        with col1:
            soil_type = st.selectbox(
                lang_manager.get_text("soil_type"),
                [lang_manager.get_text(t) for t in ["clay", "sandy", "loamy", "silt", "peat"]],
                help="Select the predominant soil type in your field"
            )
            
            soil_ph = st.number_input(
                lang_manager.get_text("soil_ph"),
                min_value=4.0,
                max_value=9.0,
                value=6.5,
                step=0.1,
                help="Soil pH level (4.0-9.0). Neutral is around 7.0"
            )
        
        with col2:
            nitrogen = st.slider(
                lang_manager.get_text("nitrogen_content"),
                min_value=0,
                max_value=100,
                value=50,
                step=5,
                help="Nitrogen content percentage in soil"
            )
            
            phosphorus = st.slider(
                lang_manager.get_text("phosphorus_content"),
                min_value=0,
                max_value=100,
                value=50,
                step=5,
                help="Phosphorus content percentage in soil"
            )
        
        potassium = st.slider(
            lang_manager.get_text("potassium_content"),
            min_value=0,
            max_value=100,
            value=50,
            step=5,
            help="Potassium content percentage in soil"
        )
        
        # Climate Information Section
        st.subheader(lang_manager.get_text("climate_information"))
        
        col1, col2 = st.columns(2)
        
        with col1:
            temperature = st.number_input(
                lang_manager.get_text("avg_temperature"),
                min_value=10,
                max_value=45,
                value=25,
                step=1,
                help="Average temperature in Celsius during growing season"
            )
            
            rainfall = st.number_input(
                lang_manager.get_text("annual_rainfall"),
                min_value=50,
                max_value=2000,
                value=800,
                step=50,
                help="Annual rainfall in millimeters"
            )
        
        with col2:
            humidity = st.slider(
                lang_manager.get_text("humidity"),
                min_value=30,
                max_value=90,
                value=60,
                step=5,
                help="Average relative humidity percentage"
            )
            
            season = st.selectbox(
                lang_manager.get_text("planting_season"),
                [lang_manager.get_text(s) for s in ["spring", "summer", "monsoon", "winter"]],
                help="Select the season when you plan to plant"
            )
        
        # Location Information Section
        st.subheader(lang_manager.get_text("location_information"))
        
        col1, col2 = st.columns(2)
        
        with col1:
            region = st.selectbox(
                lang_manager.get_text("region"),
                [lang_manager.get_text(r) for r in ["north", "south", "east", "west", "central"]],
                help="Select your geographical region"
            )
        
        with col2:
            farm_size = st.number_input(
                lang_manager.get_text("farm_size"),
                min_value=0.1,
                max_value=100.0,
                value=2.0,
                step=0.1,
                help="Size of your farm in hectares"
            )
        
        # Additional options
        st.subheader("🔧 Additional Options")
        
        col1, col2 = st.columns(2)
        
        with col1:
            num_recommendations = st.selectbox(
                "Number of recommendations",
                [1, 3, 5],
                index=1,
                help="How many crop recommendations would you like?"
            )
        
        with col2:
            include_tips = st.checkbox(
                "Include detailed farming tips",
                value=True,
                help="Include expert farming advice with recommendations"
            )
        
        # Form submission
        submitted = st.form_submit_button(
            lang_manager.get_text("get_detailed_recommendation"),
            help="Click to generate personalized crop recommendations"
        )
        
        if submitted:
            # Validate inputs
            valid_inputs = True
            
            if not validate_input(soil_ph, 4.0, 9.0, "Soil pH"):
                valid_inputs = False
            
            if not validate_input(temperature, 10, 45, "Temperature"):
                valid_inputs = False
            
            if not validate_input(rainfall, 50, 2000, "Rainfall"):
                valid_inputs = False
            
            if not validate_input(humidity, 30, 90, "Humidity"):
                valid_inputs = False
            
            if not valid_inputs:
                st.error("Please correct the input values and try again.")
                return
            
            # Process the detailed recommendation
            with st.spinner("Analyzing your conditions and generating recommendations..."):
                # Map translated selections back to English for processing
                season_map = {
                    lang_manager.get_text("spring"): "spring",
                    lang_manager.get_text("summer"): "summer", 
                    lang_manager.get_text("monsoon"): "monsoon",
                    lang_manager.get_text("winter"): "winter"
                }
                
                region_map = {
                    lang_manager.get_text("north"): "north",
                    lang_manager.get_text("south"): "south",
                    lang_manager.get_text("east"): "east", 
                    lang_manager.get_text("west"): "west",
                    lang_manager.get_text("central"): "central"
                }
                
                soil_type_map = {
                    lang_manager.get_text("clay"): "clay",
                    lang_manager.get_text("sandy"): "sandy",
                    lang_manager.get_text("loamy"): "loamy",
                    lang_manager.get_text("silt"): "silt",
                    lang_manager.get_text("peat"): "peat"
                }
                
                detailed_input = {
                    'soil_type': soil_type_map[soil_type],
                    'soil_ph': soil_ph,
                    'nitrogen': nitrogen,
                    'phosphorus': phosphorus,
                    'potassium': potassium,
                    'temperature': temperature,
                    'rainfall': rainfall,
                    'humidity': humidity,
                    'season': season_map[season],
                    'region': region_map[region],
                    'farm_size': farm_size
                }
                
                # Get recommendations
                recommendations = crop_recommender.get_multiple_recommendations(
                    detailed_input, 
                    top_n=num_recommendations
                )
            
            if recommendations:
                st.success(lang_manager.get_text("recommendations_generated"))
                
                # Display recommendations
                for i, rec in enumerate(recommendations, 1):
                    confidence_color = "green" if rec['confidence'] > 0.7 else "orange" if rec['confidence'] > 0.5 else "red"
                    
                    with st.expander(
                        f"{i}. **{rec['crop']}** - {rec['confidence']:.1%} confidence",
                        expanded=(i == 1)  # Expand first recommendation by default
                    ):
                        # Create columns for better layout
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.markdown("**📊 Crop Information**")
                            st.write(f"**Confidence:** :{confidence_color}[{rec['confidence']:.1%}]")
                            st.write(f"**Expected Yield:** {rec.get('yield', 'N/A')}")
                            st.write(f"**Growing Period:** {rec.get('growing_period', 'N/A')}")
                            st.write(f"**Water Requirement:** {rec.get('water_requirement', 'N/A')}")
                        
                        with col2:
                            st.markdown("**🌱 Suitability Analysis**")
                            # Simple suitability indicators
                            ph_suitable = "✅" if 5.5 <= soil_ph <= 7.5 else "⚠️"
                            temp_suitable = "✅" if 15 <= temperature <= 35 else "⚠️"
                            rain_suitable = "✅" if 300 <= rainfall <= 1500 else "⚠️"
                            
                            st.write(f"Soil pH: {ph_suitable}")
                            st.write(f"Temperature: {temp_suitable}")
                            st.write(f"Rainfall: {rain_suitable}")
                            st.write(f"Season: ✅")
                        
                        with col3:
                            st.markdown("**💰 Economic Factors**")
                            # This would come from market data in a real application
                            st.write("**Market Demand:** High")
                            st.write("**Price Stability:** Good")
                            st.write("**Input Costs:** Moderate")
                            st.write("**ROI Potential:** High")
                        
                        # Farming tips section
                        if include_tips and rec.get('tips'):
                            st.markdown("**💡 Expert Farming Tips:**")
                            for tip in rec.get('tips', []):
                                st.write(f"• {tip}")
                        
                        # Risk assessment
                        st.markdown("**⚠️ Risk Assessment:**")
                        risk_level = "Low" if rec['confidence'] > 0.7 else "Medium" if rec['confidence'] > 0.5 else "High"
                        risk_color = "green" if risk_level == "Low" else "orange" if risk_level == "Medium" else "red"
                        st.write(f"Overall Risk: :{risk_color}[{risk_level}]")
                        
                        if rec['confidence'] < 0.7:
                            st.warning("Consider getting soil testing done for more accurate recommendations.")
                
                # Save the best recommendation
                if recommendations:
                    data_persistence.save_recommendation(
                        user_id,
                        detailed_input,
                        recommendations[0]
                    )
                
                # Show comparison chart if multiple recommendations
                if len(recommendations) > 1:
                    st.subheader("📈 Recommendation Comparison")
                    
                    import plotly.graph_objects as go
                    
                    crops = [r['crop'] for r in recommendations]
                    confidences = [r['confidence'] for r in recommendations]
                    
                    fig = go.Figure(data=[
                        go.Bar(
                            x=crops,
                            y=confidences,
                            text=[f"{c:.1%}" for c in confidences],
                            textposition='auto',
                            marker_color=['green' if c > 0.7 else 'orange' if c > 0.5 else 'red' for c in confidences]
                        )
                    ])
                    
                    fig.update_layout(
                        title="Confidence Comparison",
                        xaxis_title="Crops",
                        yaxis_title="Confidence Level",
                        yaxis=dict(tickformat='.0%')
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                # Action buttons
                st.subheader("🎯 Next Steps")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button("📊 View Dashboard"):
                        st.session_state.page = "Dashboard"
                        st.rerun()
                
                with col2:
                    if st.button("🔄 Get New Recommendation"):
                        st.rerun()
                
                with col3:
                    if st.button("📥 Export Results"):
                        # This would implement export functionality
                        st.info("Export feature coming soon!")
                
            else:
                st.error(lang_manager.get_text("recommendation_error"))
                st.info("Please try adjusting your input parameters and try again.")
