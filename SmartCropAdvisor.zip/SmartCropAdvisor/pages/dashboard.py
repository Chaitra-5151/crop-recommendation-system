"""
Dashboard page implementation (currently integrated in main app.py)
This file can be used for future modularization
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.data_persistence import DataPersistence
from utils.language_manager import LanguageManager

def render_dashboard(user_id, lang_manager, data_persistence):
    """
    Render the dashboard page
    
    Args:
        user_id (str): User identifier
        lang_manager (LanguageManager): Language manager instance
        data_persistence (DataPersistence): Data persistence instance
    """
    st.title(lang_manager.get_text("farmer_dashboard"))
    
    # Get user history and statistics
    history = data_persistence.get_user_history(user_id)
    statistics = data_persistence.get_user_statistics(user_id)
    
    if not history:
        st.info(lang_manager.get_text("no_recommendations_yet"))
        
        # Show sample dashboard with placeholder data
        st.subheader("Dashboard Preview")
        st.markdown("This is how your dashboard will look once you start getting recommendations:")
        
        # Sample metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Recommendations", "0")
        with col2:
            st.metric("Unique Crops", "0")
        with col3:
            st.metric("Avg. Confidence", "0%")
        with col4:
            st.metric("This Month", "0")
        
        return
    
    # Convert to DataFrame for analysis
    df = pd.DataFrame(history)
    df['date'] = pd.to_datetime(df['timestamp'])
    
    # Dashboard metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            lang_manager.get_text("total_recommendations"),
            statistics['total_recommendations']
        )
    
    with col2:
        st.metric(
            lang_manager.get_text("unique_crops_recommended"),
            statistics['unique_crops']
        )
    
    with col3:
        st.metric(
            lang_manager.get_text("avg_confidence"),
            f"{statistics['average_confidence']:.1%}"
        )
    
    with col4:
        st.metric(
            lang_manager.get_text("recent_recommendations"),
            statistics['recent_recommendations']
        )
    
    # Advanced analytics section
    st.subheader("📈 Advanced Analytics")
    
    # Visualizations in tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "Crop Distribution",
        "Timeline Analysis", 
        "Seasonal Patterns",
        "Regional Analysis"
    ])
    
    with tab1:
        # Crop distribution pie chart
        crop_counts = df['recommended_crop'].value_counts()
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_pie = px.pie(
                values=crop_counts.values,
                names=crop_counts.index,
                title="Distribution of Recommended Crops"
            )
            st.plotly_chart(fig_pie, use_container_width=True)
        
        with col2:
            # Confidence by crop
            confidence_by_crop = df.groupby('recommended_crop')['confidence'].mean().sort_values(ascending=False)
            
            fig_bar = px.bar(
                x=confidence_by_crop.index,
                y=confidence_by_crop.values,
                title="Average Confidence by Crop",
                labels={'x': 'Crop', 'y': 'Average Confidence'}
            )
            fig_bar.update_layout(xaxis_tickangle=-45)
            st.plotly_chart(fig_bar, use_container_width=True)
    
    with tab2:
        # Timeline analysis
        df_monthly = df.groupby(df['date'].dt.to_period('M')).size().reset_index()
        df_monthly['date'] = df_monthly['date'].astype(str)
        
        fig_timeline = px.line(
            df_monthly,
            x='date',
            y=0,
            title="Recommendations Over Time",
            labels={'0': 'Number of Recommendations', 'date': 'Month'}
        )
        st.plotly_chart(fig_timeline, use_container_width=True)
        
        # Daily pattern
        df['hour'] = df['date'].dt.hour
        hourly_pattern = df.groupby('hour').size()
        
        fig_hourly = px.bar(
            x=hourly_pattern.index,
            y=hourly_pattern.values,
            title="Recommendation Requests by Hour of Day",
            labels={'x': 'Hour of Day', 'y': 'Number of Requests'}
        )
        st.plotly_chart(fig_hourly, use_container_width=True)
    
    with tab3:
        # Seasonal patterns
        season_crop_matrix = pd.crosstab(df['season'], df['recommended_crop'])
        
        fig_heatmap = px.imshow(
            season_crop_matrix.values,
            x=season_crop_matrix.columns,
            y=season_crop_matrix.index,
            title="Seasonal Crop Recommendation Patterns",
            labels={'color': 'Number of Recommendations'},
            aspect="auto"
        )
        st.plotly_chart(fig_heatmap, use_container_width=True)
        
        # Environmental conditions by season
        col1, col2 = st.columns(2)
        
        with col1:
            avg_temp_by_season = df.groupby('season')['temperature'].mean()
            fig_temp = px.bar(
                x=avg_temp_by_season.index,
                y=avg_temp_by_season.values,
                title="Average Temperature by Season",
                labels={'x': 'Season', 'y': 'Temperature (°C)'}
            )
            st.plotly_chart(fig_temp, use_container_width=True)
        
        with col2:
            avg_rainfall_by_season = df.groupby('season')['rainfall'].mean()
            fig_rainfall = px.bar(
                x=avg_rainfall_by_season.index,
                y=avg_rainfall_by_season.values,
                title="Average Rainfall by Season",
                labels={'x': 'Season', 'y': 'Rainfall (mm)'}
            )
            st.plotly_chart(fig_rainfall, use_container_width=True)
    
    with tab4:
        # Regional analysis
        region_crop_matrix = pd.crosstab(df['region'], df['recommended_crop'])
        
        fig_region_heatmap = px.imshow(
            region_crop_matrix.values,
            x=region_crop_matrix.columns,
            y=region_crop_matrix.index,
            title="Regional Crop Recommendation Patterns",
            labels={'color': 'Number of Recommendations'},
            aspect="auto"
        )
        st.plotly_chart(fig_region_heatmap, use_container_width=True)
        
        # Environmental conditions by region
        col1, col2 = st.columns(2)
        
        with col1:
            soil_ph_by_region = df.groupby('region')['soil_ph'].mean()
            fig_ph = px.bar(
                x=soil_ph_by_region.index,
                y=soil_ph_by_region.values,
                title="Average Soil pH by Region",
                labels={'x': 'Region', 'y': 'Soil pH'}
            )
            st.plotly_chart(fig_ph, use_container_width=True)
        
        with col2:
            humidity_by_region = df.groupby('region')['humidity'].mean()
            fig_humidity = px.bar(
                x=humidity_by_region.index,
                y=humidity_by_region.values,
                title="Average Humidity by Region",
                labels={'x': 'Region', 'y': 'Humidity (%)'}
            )
            st.plotly_chart(fig_humidity, use_container_width=True)
    
    # Data export section
    st.subheader("📥 Export Data")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Export to CSV"):
            filepath = data_persistence.export_user_data(user_id, 'csv')
            if filepath:
                st.success(f"Data exported to: {filepath}")
            else:
                st.error("Failed to export data")
    
    with col2:
        if st.button("Export to JSON"):
            filepath = data_persistence.export_user_data(user_id, 'json')
            if filepath:
                st.success(f"Data exported to: {filepath}")
            else:
                st.error("Failed to export data")
    
    # Recent recommendations table
    st.subheader(lang_manager.get_text("recent_recommendations_history"))
    
    recent_df = df.tail(10)[['date', 'recommended_crop', 'confidence', 'soil_ph', 'temperature', 'rainfall']]
    recent_df['date'] = recent_df['date'].dt.strftime('%Y-%m-%d %H:%M')
    recent_df['confidence'] = recent_df['confidence'].apply(lambda x: f"{x:.1%}")
    
    # Rename columns for display
    display_df = recent_df.rename(columns={
        'date': lang_manager.get_text('date'),
        'recommended_crop': lang_manager.get_text('crop'),
        'confidence': lang_manager.get_text('confidence'),
        'soil_ph': lang_manager.get_text('soil_ph'),
        'temperature': lang_manager.get_text('temperature'),
        'rainfall': lang_manager.get_text('rainfall')
    })
    
    st.dataframe(display_df, use_container_width=True)
